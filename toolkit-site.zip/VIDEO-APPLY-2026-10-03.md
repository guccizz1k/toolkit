# TOOLKIT - video insight application (2026-10-03)

Applied only the parts that fit TOOLKIT:
- solve a concrete user problem instead of mass-producing generic AI content
- use helpful content as a path into the actual tool
- start with a small number of specific, validated problem pages
- keep human-reviewed, useful explanations and link each guide to a working tool
- make unmet user problems easier to submit through the existing contact path

Added guide hub and four initial high-intent guides:
- /guides/image-300kb/
- /guides/iphone-heic-jpg/
- /guides/pdf-merge-mobile/
- /guides/pdf-to-jpg/

No existing conversion logic was intentionally changed.
