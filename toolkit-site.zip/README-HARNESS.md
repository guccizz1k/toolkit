# TOOLKIT Project Harness

현재 TOOLKIT 정적 사이트를 변경하지 않고 저장소 루트에 추가되는 개발·검증 체계다.

- `npm run check`: 빠른 정적 구조/링크/JS 문법/보안 신호 검사
- `npm run verify`: 빠른 검사 + 변경/배포 계약 검사
- `npm run verify:full`: 위 검사 + Playwright 실제 변환/오류/레이아웃/개인정보 회귀
- `npm run release`: 검증된 `site/` + `vercel.json`을 `dist/toolkit-site.zip`으로 패키징
- `npm run release:check`: 배포 ZIP 파일별 SHA 검증

GitHub Actions는 push, pull request, 수동 실행 때 full 검증을 수행한다. 브라우저/네트워크가 없는 환경에서 실행하지 못한 full 검사는 통과로 기록하면 안 된다.
