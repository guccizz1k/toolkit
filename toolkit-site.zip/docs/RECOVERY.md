# 배포와 복구

1. 배포 직전 `npm run verify:full`.
2. `npm run release && npm run release:check`.
3. 현재 Git 커밋 SHA와 Vercel 현재 배포 ID를 기록한다.
4. 검증된 `dist/toolkit-site.zip`과 `dist/RELEASE.json`의 해시가 맞는지 확인한다.
5. 배포 후 홈, 핵심 변환 1개, 오류 입력 1개, 모바일/PC를 확인한다.

문제가 생기면 새 파일을 임의로 다시 수정하지 말고 **직전 Git 커밋 또는 Vercel의 직전 정상 배포**로 되돌린다. 사용자 데이터 삭제, 공유 범위 변경, 유료 서비스 변경은 복구 절차에 포함하지 않으며 별도 승인이 필요하다.
