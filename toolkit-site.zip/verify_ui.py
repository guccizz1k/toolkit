from pathlib import Path
from bs4 import BeautifulSoup
from PIL import Image
import zipfile, subprocess, re
r=Path('/mnt/data/toolkit_edit');p=r/'site';s=BeautifulSoup((p/'index.html').read_text(),'html.parser');js=(p/'home.js').read_text();css=(p/'style.css').read_text();
checks=[]
def check(name,fn):
 try:fn();checks.append((name,'PASS'))
 except Exception as e:checks.append((name,'FAIL '+str(e)))
def require(x,msg):
 if not x:raise AssertionError(msg)
def t1():
 require(subprocess.run(['node','--check',str(p/'home.js')]).returncode==0,'syntax');require(len(s.select('.tool-card[data-search]'))==21,'cards');require(s.select_one('.hero-kicker').text=='무료 파일 변환과 편집, 한 곳에서 간편하게','copy')
def t2():
 require(all(x in js for x in ['toolSearchSuggestions','window.location.assign','scrollIntoView','addEventListener(\'input\'','addEventListener(\'keydown\'']), 'search behaviors');require(all(x in js for x in ['엑셀','excel','document','pdf']), 'aliases');require(len(s.select('.toolkit-search-suggestions'))==1,'suggestions');require(all((p/c['href'].lstrip('/')).exists() for c in s.select('.tool-card[href]')),'tool routes')
def t3():
 im=Image.open(p/'toolkit-polar-bear.png');require(im.mode=='RGBA','transparency');require(im.getchannel('A').getextrema()==(0,255),'mask');require(s.select_one('.toolkit-mascot img')['src']=='/toolkit-polar-bear.png','image');require('max-width:520px' in css and '.category-overview .category-card' in css,'responsive');require(not s.select_one('#popular-searches'),'redundant links')
def t4():
 require('google-adsense-account' in str(s) and 'naver-site-verification' in str(s),'SEO tags');require((p/'robots.txt').exists() and (p/'sitemap.xml').exists(),'SEO files');require((p/'en/index.html').exists(),'English');require((p/'ads.js').exists(),'ads')
def t5():
 z=Path('/mnt/data/toolkit-site.zip');require(z.exists(),'zip missing');
 with zipfile.ZipFile(z) as f:
  require(f.testzip() is None,'corrupt');require('site/index.html' in f.namelist() and 'site/toolkit-polar-bear.png' in f.namelist(),'contents');require(len(f.namelist())>200,'missing files')
for n,fn in [('1 syntax & content',t1),('2 search & routes',t2),('3 mascot & responsive',t3),('4 SEO & existing features',t4),('5 ZIP integrity',t5)]:check(n,fn)
for n,v in checks:print(n,v)
if any(v!='PASS' for _,v in checks):raise SystemExit(1)
