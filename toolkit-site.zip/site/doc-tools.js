(()=>{
'use strict';
const $=s=>document.querySelector(s);
let currentUrl=null;
const DOC_LIMIT=50_000_000;
function result(msg,err=false){const el=$('#result');if(!el)return;el.className='result'+(err?' error':'');el.innerHTML=msg;}
function clearDownload(){if(currentUrl){URL.revokeObjectURL(currentUrl);currentUrl=null;}}
function safeBase(name){return (name||'converted').replace(/\.[^.]+$/,'').replace(/[\\/:*?"<>|]+/g,'-').slice(0,100)||'converted';}
function download(blob,name,detail=''){clearDownload();currentUrl=URL.createObjectURL(blob);result(`${detail?detail+'<br>':''}<a class="download-btn" href="${currentUrl}" download="${name}">결과 파일 저장</a>`);}
function ext(name){return (name.split('.').pop()||'').toLowerCase();}
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function htmlToText(html){const d=document.createElement('div');d.innerHTML=html;return d.textContent||d.innerText||'';}
function ensureSize(file){if(file.size>DOC_LIMIT)throw new Error('안정적인 브라우저 처리를 위해 문서 파일은 50MB 이하를 권장·지원합니다.');}
function loadScript(src){return new Promise((resolve,reject)=>{const found=[...document.scripts].find(s=>s.src===src);if(found){if(found.dataset.loaded==='1'||found.readyState==='complete')return resolve();found.addEventListener('load',resolve,{once:true});found.addEventListener('error',()=>reject(new Error('load failed')),{once:true});return;}const s=document.createElement('script');s.src=src;s.async=true;s.onload=()=>{s.dataset.loaded='1';resolve();};s.onerror=()=>{s.remove();reject(new Error('load failed'));};document.head.appendChild(s);});}
async function ensureGlobal(name,urls,errorMessage){if(window[name])return window[name];for(const url of urls){try{await loadScript(url);if(window[name])return window[name];}catch(e){console.warn(`${name} load failed`,url,e);}}throw new Error(errorMessage);}
async function ensureXLSX(){return ensureGlobal('XLSX',[
  'https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js'
],'엑셀 변환 모듈을 불러오지 못했습니다. 네트워크 상태를 확인해 주세요.');}
async function ensureMammoth(){return ensureGlobal('mammoth',[
  'https://cdn.jsdelivr.net/npm/mammoth@1.12.3/mammoth.browser.min.js',
  'https://unpkg.com/mammoth@1.12.3/mammoth.browser.min.js'
],'Word 변환 모듈을 불러오지 못했습니다. 네트워크 상태를 확인해 주세요.');}
async function ensureJSZip(){return ensureGlobal('JSZip',[
  'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js',
  'https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js'
],'HWPX 처리 모듈을 불러오지 못했습니다. 네트워크 상태를 확인해 주세요.');}
let hwpModuleCache=null;
async function hwpModule(){
  if(hwpModuleCache)return hwpModuleCache;
  const urls=[
    'https://esm.sh/@ohah/hwpjs@0.1.0-rc.10?bundle',
    'https://cdn.jsdelivr.net/npm/@ohah/hwpjs@0.1.0-rc.10/+esm'
  ];
  for(const url of urls){try{const mod=await import(url);if(mod?.toHtml||mod?.toMarkdown){hwpModuleCache=mod;return mod;}}catch(e){console.warn('HWP module load failed',url,e);}}
  throw new Error('HWP 변환 모듈을 불러오지 못했습니다. 네트워크 상태를 확인하거나 HWPX 파일을 이용해 주세요.');
}
async function hwpxText(file){
  const Zip=await ensureJSZip();
  const zip=await Zip.loadAsync(await file.arrayBuffer());
  const defaultNames=Object.keys(zip.files).filter(n=>/^Contents\/section\d+\.xml$/i.test(n)).sort((a,b)=>{const na=+(a.match(/section(\d+)/i)||[,0])[1],nb=+(b.match(/section(\d+)/i)||[,0])[1];return na-nb;});
  let names=defaultNames;
  const hpfEntry=zip.file('Contents/content.hpf');
  if(hpfEntry){
    try{
      const hpfXml=await hpfEntry.async('text'),hpfDoc=new DOMParser().parseFromString(hpfXml,'application/xml');
      if(!hpfDoc.querySelector('parsererror')){
        const manifest=new Map();
        for(const el of [...hpfDoc.getElementsByTagName('*')].filter(el=>el.localName==='item')){
          const id=el.getAttribute?.('id'),href=el.getAttribute?.('href');
          if(id&&href)manifest.set(id,href);
        }
        const ordered=[];
        for(const ref of [...hpfDoc.getElementsByTagName('*')].filter(el=>el.localName==='itemref')){
          const idref=ref.getAttribute?.('idref'),href=idref?manifest.get(idref):null;
          if(!href)continue;
          let path=href.replace(/^\.\//,'').replace(/^\//,'');
          if(!path.startsWith('Contents/'))path='Contents/'+path;
          if(/^Contents\/section\d+\.xml$/i.test(path)&&zip.files[path])ordered.push(path);
        }
        if(ordered.length)names=ordered;
      }
    }catch(e){console.warn('HWPX spine parse fallback',e);}
  }
  if(!names.length)throw new Error('HWPX 본문을 찾을 수 없습니다. 파일이 손상되었거나 지원하지 않는 HWPX 구조일 수 있습니다.');
  const paras=[];
  for(const name of names){
    const entry=zip.file(name);if(!entry)continue;
    const xml=await entry.async('text');
    const doc=new DOMParser().parseFromString(xml,'application/xml');
    if(doc.querySelector('parsererror'))continue;
    const ps=[...doc.getElementsByTagName('*')].filter(el=>el.localName==='p');
    for(const p of ps){const ts=[...p.getElementsByTagName('*')].filter(el=>el.localName==='t').map(el=>el.textContent||'').join('');if(ts.trim())paras.push(ts);}
  }
  if(!paras.length)throw new Error('HWPX에서 본문 텍스트를 읽지 못했습니다.');
  return paras;
}
async function handleExcel(form){
  const file=form.elements.files.files[0];if(!file)throw new Error('엑셀 또는 CSV 파일을 선택해 주세요.');ensureSize(file);
  const XLSX=await ensureXLSX();
  const wb=XLSX.read(await file.arrayBuffer(),{type:'array',cellDates:true});
  if(!wb.SheetNames?.length)throw new Error('시트를 찾을 수 없습니다. 파일이 손상되지 않았는지 확인해 주세요.');
  const out=form.elements.format.value,base=safeBase(file.name);
  if(!['XLSX','CSV','ODS','HTML'].includes(out))throw new Error('지원하지 않는 출력 형식입니다.');
  if(out==='XLSX'||out==='ODS'){
    const bookType=out.toLowerCase(),data=XLSX.write(wb,{bookType,type:'array'});
    download(new Blob([data],{type:out==='XLSX'?'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':'application/vnd.oasis.opendocument.spreadsheet'}),`${base}.${bookType}`,`완료 · ${wb.SheetNames.length}개 시트 유지`);return;
  }
  const ws=wb.Sheets[wb.SheetNames[0]];
  if(!ws)throw new Error('첫 번째 시트를 읽지 못했습니다.');
  if(out==='CSV'){
    const csv=XLSX.utils.sheet_to_csv(ws);
    download(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'}),`${base}.csv`,`완료 · 첫 번째 시트(${escapeHtml(wb.SheetNames[0])})를 CSV로 변환`);return;
  }
  const table=XLSX.utils.sheet_to_html(ws);
  const html=`<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${escapeHtml(base)}</title><style>body{font-family:sans-serif;padding:20px;overflow:auto}table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:6px;white-space:nowrap}</style></head><body>${table}</body></html>`;
  download(new Blob([html],{type:'text/html;charset=utf-8'}),`${base}.html`,'완료 · 첫 번째 시트를 HTML 표로 변환');
}
async function handleWord(form){
  const file=form.elements.files.files[0];if(!file)throw new Error('DOCX 파일을 선택해 주세요.');ensureSize(file);
  if(ext(file.name)!=='docx')throw new Error('현재 워드 변환은 DOCX 파일을 지원합니다.');
  const mammoth=await ensureMammoth(),buffer=await file.arrayBuffer(),out=form.elements.format.value,base=safeBase(file.name);
  if(out==='TXT'){
    const r=await mammoth.extractRawText({arrayBuffer:buffer});
    download(new Blob([r.value||''],{type:'text/plain;charset=utf-8'}),`${base}.txt`,`완료 · Word 본문 텍스트 추출${r.messages?.length?` · 알림 ${r.messages.length}건`:''}`);return;
  }
  if(out!=='HTML')throw new Error('지원하지 않는 출력 형식입니다.');
  const r=await mammoth.convertToHtml({arrayBuffer:buffer});
  const html=`<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${escapeHtml(base)}</title><style>body{max-width:850px;margin:40px auto;padding:0 20px;font-family:sans-serif;line-height:1.65}img{max-width:100%;height:auto}table{border-collapse:collapse;max-width:100%}td,th{border:1px solid #ddd;padding:6px}</style></head><body>${r.value||''}</body></html>`;
  download(new Blob([html],{type:'text/html;charset=utf-8'}),`${base}.html`,`완료 · Word 문서를 HTML로 변환${r.messages?.length?` · 알림 ${r.messages.length}건`:''}`);
}
async function handleHwp(form){
  const file=form.elements.files.files[0];if(!file)throw new Error('HWP 또는 HWPX 파일을 선택해 주세요.');ensureSize(file);
  const e=ext(file.name),out=form.elements.format.value,base=safeBase(file.name);let html='',markdown='',text='';
  if(!['HTML','TXT','MARKDOWN'].includes(out))throw new Error('지원하지 않는 출력 형식입니다.');
  if(e==='hwpx'){
    const paras=await hwpxText(file);text=paras.join('\n\n');markdown=text;html=paras.map(p=>`<p>${escapeHtml(p)}</p>`).join('\n');
  }else if(e==='hwp'){
    const mod=await hwpModule(),data=new Uint8Array(await file.arrayBuffer());
    if(out==='MARKDOWN'&&typeof mod.toMarkdown==='function'){
      const r=await mod.toMarkdown(data,{image:'base64',useHtml:true});markdown=r?.markdown||r?.value||String(r||'');
    }else if(typeof mod.toHtml==='function'){
      const r=await mod.toHtml(data,{includeVersion:false});html=typeof r==='string'?r:(r?.html||String(r||''));
    }else if(typeof mod.toMarkdown==='function'){
      const r=await mod.toMarkdown(data,{image:'base64',useHtml:true});markdown=r?.markdown||'';html=`<pre>${escapeHtml(markdown)}</pre>`;
    }else throw new Error('현재 HWP 모듈에서 사용할 수 있는 변환 API를 찾지 못했습니다.');
    if(!text)text=html?htmlToText(html):markdown.replace(/[#*_`>-]/g,' ');
  }else throw new Error('HWP 또는 HWPX 파일만 선택해 주세요.');
  if(out==='TXT'){
    if(!text)text=html?htmlToText(html):markdown;
    download(new Blob([text],{type:'text/plain;charset=utf-8'}),`${base}.txt`,'완료 · 한글 문서 내용 중심 TXT 변환');return;
  }
  if(out==='MARKDOWN'){
    if(!markdown)markdown=text||htmlToText(html);
    download(new Blob([markdown],{type:'text/markdown;charset=utf-8'}),`${base}.md`,'완료 · 한글 문서 내용 중심 Markdown 변환');return;
  }
  if(!html)html=(text||markdown).split(/\n{2,}/).map(p=>`<p>${escapeHtml(p)}</p>`).join('\n');
  const looksComplete=/<!doctype\s+html|<html[\s>]/i.test(html);
  const page=looksComplete?html:`<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${escapeHtml(base)}</title><style>body{max-width:850px;margin:40px auto;padding:0 20px;font-family:sans-serif;line-height:1.65}img{max-width:100%;height:auto}table{border-collapse:collapse;max-width:100%}td,th{border:1px solid #ddd;padding:6px}</style></head><body>${html}</body></html>`;
  download(new Blob([page],{type:'text/html;charset=utf-8'}),`${base}.html`,'완료 · 한글 문서 HTML 변환');
}
async function submit(e){e.preventDefault();const form=e.currentTarget,btn=form.querySelector('.primary');const old=btn.textContent;btn.disabled=true;btn.textContent='변환 중…';result('파일을 읽고 있습니다…');try{const id=document.body.dataset.tool;if(id==='excel')await handleExcel(form);else if(id==='word')await handleWord(form);else if(id==='hwp')await handleHwp(form);else throw new Error('지원하지 않는 문서 도구입니다.');}catch(err){console.error(err);result(err?.message||'변환에 실패했습니다.',true);}finally{btn.disabled=false;btn.textContent=old;}}
$('#toolForm')?.addEventListener('submit',submit);
window.addEventListener('beforeunload',clearDownload);
})();
