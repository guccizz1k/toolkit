(()=>{
'use strict';
const q=document.getElementById('toolSearch');
const grid=document.getElementById('toolGrid');
const cards=grid?[...grid.querySelectorAll('.tool-card')]:[];
const count=document.getElementById('searchCount');
const empty=document.getElementById('searchEmpty');
function setEmpty(n){if(empty)empty.hidden=n!==0;}
function showAll(){for(const c of cards)c.hidden=false;if(count)count.textContent='';setEmpty(cards.length);}
function apply(){const s=(q?.value||'').trim().toLocaleLowerCase('ko-KR');if(!s){showAll();return;}let n=0;for(const c of cards){const hay=(c.dataset.search||c.textContent).toLocaleLowerCase('ko-KR');const show=hay.includes(s);c.hidden=!show;if(show)n++;}if(count)count.textContent=`${n}개 도구 찾음`;setEmpty(n);}
q?.addEventListener('input',apply);
document.querySelectorAll('[data-category-filter]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();const cat=a.dataset.categoryFilter;if(q)q.value='';let n=0;for(const c of cards){const show=c.dataset.cat===cat;c.hidden=!show;if(show)n++;}if(count)count.textContent=`${n}개 도구`;setEmpty(n);document.getElementById('all-tools')?.scrollIntoView({behavior:'smooth',block:'start'});}));
})();
