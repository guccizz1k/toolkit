(()=>{
'use strict';
const q=document.getElementById('toolSearch');
const cards=[...document.querySelectorAll('.tool-card[data-search]')];
const sections=[...document.querySelectorAll('[data-category-section]')];
const count=document.getElementById('searchCount');
const empty=document.getElementById('searchEmpty');
const total=document.getElementById('toolTotal');
function apply(){
  const s=(q?.value||'').trim().toLocaleLowerCase('ko-KR');
  let n=0;
  for(const c of cards){
    const hay=(c.dataset.search||c.textContent).toLocaleLowerCase('ko-KR');
    const show=!s||hay.includes(s);
    c.hidden=!show;if(show)n++;
  }
  for(const sec of sections){
    const visible=[...sec.querySelectorAll('.tool-card')].some(c=>!c.hidden);
    sec.hidden=!visible;
  }
  if(count) count.textContent=s?`${n}개 찾음`:'';
  if(total) total.textContent=s?`검색 결과 ${n}개`:`총 ${cards.length}개`;
  if(empty) empty.hidden=n!==0;
}
q?.addEventListener('input',apply);
document.querySelectorAll('.category-card,.category-quickbar a').forEach(a=>a.addEventListener('click',()=>{if(q&&q.value){q.value='';apply();}}));
})();/* NEW 배지 자동 만료: data-new-until 날짜가 지나면 배지를 숨깁니다. */
(()=>{const today=new Date().toISOString().slice(0,10);document.querySelectorAll('.new-badge[data-new-until]').forEach(b=>{if(b.dataset.newUntil<today)b.remove()})})();
