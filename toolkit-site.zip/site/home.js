(()=>{
'use strict';
const q=document.getElementById('toolSearch');
const cards=[...document.querySelectorAll('.tool-card[data-search]')];
const sections=[...document.querySelectorAll('[data-category-section]')];
const count=document.getElementById('searchCount');
const empty=document.getElementById('searchEmpty');
const total=document.getElementById('toolTotal');
const pop=document.getElementById('toolSearchSuggestions');
const aliases={'엑셀':'document','excel':'document','워드':'document','word':'document','한글':'document','hwp':'document','pdf':'pdf','피디에프':'pdf','이미지':'image','사진':'image','동영상':'video','영상':'video','바코드':'code','qr':'code','글자':'text'};
function normalize(s){return String(s||'').trim().toLocaleLowerCase('ko-KR');}
function matching(term){return cards.filter(c=>{const hay=normalize(c.dataset.search||c.textContent);return hay.includes(term)||(aliases[term]&&c.dataset.cat===aliases[term]);});}
function apply(){
 const term=normalize(q?.value);const matches=term?matching(term):cards;const set=new Set(matches);
 for(const c of cards)c.hidden=!set.has(c);
 for(const sec of sections)sec.hidden=![...sec.querySelectorAll('.tool-card')].some(c=>!c.hidden);
 if(count)count.textContent=term?`${matches.length}개 도구` : '';
 if(total)total.textContent=term?`검색 결과 ${matches.length}개`:`총 ${cards.length}개`;
 if(empty)empty.hidden=matches.length!==0;
 if(pop){pop.replaceChildren();if(term){
  const caption=document.createElement('div');caption.className='toolkit-search-caption';caption.textContent=matches.length?'추천 도구 · 선택하면 바로 이동':'검색 결과가 없습니다';pop.append(caption);
  for(const c of matches.slice(0,6)){const a=document.createElement('a');a.href=c.getAttribute('href');a.setAttribute('role','option');a.textContent=c.querySelector('strong')?.textContent?.trim()||'도구 바로가기';pop.append(a);}
  if(matches.length>6){const more=document.createElement('button');more.type='button';more.textContent=`나머지 ${matches.length-6}개 결과 보기 ↓`;more.addEventListener('click',()=>{close();document.getElementById('all-tools')?.scrollIntoView({behavior:'smooth'});});pop.append(more);}
 }pop.hidden=!term;q?.setAttribute('aria-expanded',String(Boolean(term)));}
 return matches;
}
function close(){if(pop)pop.hidden=true;q?.setAttribute('aria-expanded','false');}
q?.addEventListener('input',apply);
q?.addEventListener('keydown',e=>{if(e.key==='Escape'){close();return;}if(e.key==='Enter'){e.preventDefault();const matches=apply();if(matches.length===1){window.location.assign(matches[0].getAttribute('href'));}else{close();document.getElementById('all-tools')?.scrollIntoView({behavior:'smooth'});}}});
document.addEventListener('pointerdown',e=>{if(!e.target.closest('.toolkit-search-wrap'))close();});
q?.addEventListener('focus',()=>{if(normalize(q.value))apply();});
document.querySelectorAll('.category-card').forEach(a=>a.addEventListener('click',()=>{if(q&&q.value){q.value='';apply();close();}}));
})();
(()=>{const today=new Date().toISOString().slice(0,10);document.querySelectorAll('.new-badge[data-new-until]').forEach(b=>{if(b.dataset.newUntil<today)b.remove();});})();
