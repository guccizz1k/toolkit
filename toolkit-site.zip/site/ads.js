(()=>{
'use strict';
const cfg=window.TOOLKIT_ADS||{};
if(!cfg.enabled)return;
const client=String(cfg.client||'').trim();
if(!/^ca-pub-\d+$/.test(client)){console.warn('TOOLKIT ads: valid AdSense client ID is required.');return;}
const shells=[...document.querySelectorAll('.ad-shell')];
const manual=shells.map(shell=>({shell,slot:String((cfg.slots||{})[shell.dataset.adPosition]||'').trim()})).filter(x=>/^\d+$/.test(x.slot));
const s=document.createElement('script');
s.async=true;s.crossOrigin='anonymous';s.src=`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${encodeURIComponent(client)}`;
s.onload=()=>{for(const {shell,slot} of manual){const target=shell.querySelector('.ad-target');if(!target)continue;const ins=document.createElement('ins');ins.className='adsbygoogle';ins.style.display='block';ins.dataset.adClient=client;ins.dataset.adSlot=slot;ins.dataset.adFormat='auto';ins.dataset.fullWidthResponsive='true';target.replaceChildren(ins);shell.hidden=false;try{(window.adsbygoogle=window.adsbygoogle||[]).push({})}catch(e){console.warn('TOOLKIT ads: slot render failed',e)}}};
s.onerror=()=>console.warn('TOOLKIT ads: AdSense script could not be loaded.');
document.head.appendChild(s);
})();
