/* AdSense 승인 후 실제 값만 입력하세요. 승인 전에는 enabled:false를 유지합니다. */
window.TOOLKIT_ADS={enabled:false,client:'',slots:{'home-mid':'','after-tool':'','after-related':''}};
