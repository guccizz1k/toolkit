/* TOOLKIT extra tools: image crop, EXIF removal, PDF rotation, video-to-GIF, and audio extraction. */
(()=>{
'use strict';
const $=s=>document.querySelector(s);
const TOOL=document.body.dataset.tool;
let activeUrl=null;

/* ---------- shared ---------- */
const LIBS={
  pdfLib:{global:'PDFLib',urls:['https://cdn.jsdelivr.net/npm/pdf-lib@1.17.1/dist/pdf-lib.min.js','https://unpkg.com/pdf-lib@1.17.1/dist/pdf-lib.min.js']},
  jszip:{global:'JSZip',urls:['https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js','https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js']}
};
const pending=new Map();
function loadScript(src){return new Promise((res,rej)=>{const s=document.createElement('script');s.src=src;s.async=true;s.crossOrigin='anonymous';s.onload=res;s.onerror=()=>{s.remove();rej(new Error('Could not load a required processing module.'))};document.head.appendChild(s)})}
async function loadLib(key){const lib=LIBS[key];if(window[lib.global])return window[lib.global];if(pending.has(key))return pending.get(key);const p=(async()=>{let last;for(const u of lib.urls){try{await loadScript(u);if(window[lib.global])return window[lib.global]}catch(e){last=e}}throw last||new Error('Could not load a required processing module. Check your network connection.')})();pending.set(key,p);try{return await p}catch(e){pending.delete(key);throw e}}
function clearUrl(){if(activeUrl){URL.revokeObjectURL(activeUrl);activeUrl=null}}
function hideResult(){const r=$('#result');if(r){r.className='result hidden';r.replaceChildren()}}
function showError(msg){clearUrl();const r=$('#result');if(!r)return;r.className='result error';r.setAttribute('role','alert');r.textContent=msg}
function showInfo(msg){const r=$('#result');if(!r)return;r.className='result';r.setAttribute('role','status');r.textContent=msg}
function offer(blob,name,message){if(!blob||!blob.size)throw new Error('Could not create the output file.');clearUrl();activeUrl=URL.createObjectURL(blob);const r=$('#result');r.className='result';r.setAttribute('role','status');r.replaceChildren();const p=document.createElement('div');p.textContent=message;r.appendChild(p);const a=document.createElement('a');a.className='download-btn';a.href=activeUrl;a.download=name;a.textContent='Save output file';r.appendChild(a)}
function base(name='file'){let s=String(name).normalize?String(name).normalize('NFC'):String(name);s=s.replace(/\.[^.]+$/,'');try{s=s.replace(/[^\p{L}\p{N}._-]+/gu,'-')}catch(_){s=s.replace(/[^a-zA-Z0-9가-힣._-]+/g,'-')}return(s.replace(/^-+|-+$/g,'')||'toolkit').slice(0,80)}
function kb(n){return `${(n/1000).toFixed(2)}KB`}
function uniqueName(used,name){if(!used.has(name)){used.add(name);return name}const m=name.match(/^(.*?)(\.[^.]+)$/)||[null,name,''];let i=2;while(used.has(`${m[1]}-${i}${m[2]}`))i++;const n=`${m[1]}-${i}${m[2]}`;used.add(n);return n}
async function decodeImage(file){if('createImageBitmap'in window){try{return await createImageBitmap(file)}catch(_){}}return await new Promise((resolve,reject)=>{const img=new Image(),u=URL.createObjectURL(file);img.onload=()=>{URL.revokeObjectURL(u);resolve(img)};img.onerror=()=>{URL.revokeObjectURL(u);reject(new Error('Could not read the image. Make sure it is a JPG, PNG or WEBP file.'))};img.src=u})}
function dims(img){return{w:img.width||img.naturalWidth,h:img.height||img.naturalHeight}}
function toBlob(canvas,type,q){return new Promise((res,rej)=>canvas.toBlob(b=>{if(!b)return rej(new Error('This browser could not save the selected format.'));if(b.type&&b.type!==type)return rej(new Error(type==='image/webp'?'This browser cannot save WEBP files. Choose JPG or PNG instead.':'Could not save the requested image format.'));res(b)},type,q))}
function typeOf(fmt){return fmt==='PNG'?'image/png':fmt==='WEBP'?'image/webp':'image/jpeg'}
function extOf(fmt){return fmt==='JPG'?'jpg':fmt.toLowerCase()}
function sameFormat(file){const t=(file.type||'').toLowerCase(),n=file.name||'';if(t==='image/png'||/\.png$/i.test(n))return'PNG';if(t==='image/webp'||/\.webp$/i.test(n))return'WEBP';return'JPG'}
function checkSize(w,h){if(w>16384||h>16384||w*h>64000000)throw new Error('The image is too large. Resize it to smaller dimensions first.')}
function withButton(form,label,fn){return async e=>{e.preventDefault();const btn=form.querySelector('.primary');const old=btn.textContent;btn.disabled=true;btn.textContent=label;hideResult();try{await fn()}catch(err){console.error(err);showError(err?.message||'Processing failed. Check the file format and browser support.')}finally{btn.disabled=false;btn.textContent=old}}}

/* ---------- image crop ---------- */
function initCrop(){
  const form=$('#toolForm'),fileIn=form.elements.files,ratioSel=form.elements.ratio,posX=form.elements.posx,posY=form.elements.posy,zoom=form.elements.zoom;
  const preview=$('#cropPreview'),wrap=$('#cropPreviewWrap');let img=null;
  function ratio(){const [a,b]=String(ratioSel.value).split(':').map(Number);return a>0&&b>0?a/b:null}
  function rect(){const {w,h}=dims(img);const r=ratio()||w/h;const z=Math.max(1,Number(zoom.value)||1);let cw,ch;if(w/h>r){ch=h;cw=h*r}else{cw=w;ch=w/r}cw/=z;ch/=z;const x=(w-cw)*(Number(posX.value)/100),y=(h-ch)*(Number(posY.value)/100);return{x:Math.round(x),y:Math.round(y),w:Math.max(1,Math.round(cw)),h:Math.max(1,Math.round(ch))}}
  function draw(){if(!img)return;const {w,h}=dims(img);const max=Math.min(wrap.clientWidth||600,600);const s=Math.min(1,max/w,420/h);preview.width=Math.round(w*s);preview.height=Math.round(h*s);const c=preview.getContext('2d');c.drawImage(img,0,0,preview.width,preview.height);const r=rect();c.fillStyle='rgba(20,18,40,.55)';c.beginPath();c.rect(0,0,preview.width,preview.height);c.rect(r.x*s,r.y*s,r.w*s,r.h*s);c.fill('evenodd');c.strokeStyle='#fff';c.lineWidth=2;c.strokeRect(r.x*s+1,r.y*s+1,r.w*s-2,r.h*s-2);$('#cropInfo').textContent=`Crop area ${r.w}×${r.h}px`}
  fileIn.addEventListener('change',async()=>{hideResult();img=null;wrap.hidden=true;const f=fileIn.files[0];if(!f)return;try{img=await decodeImage(f);wrap.hidden=false;draw()}catch(err){showError(err.message)}});
  [ratioSel,posX,posY,zoom].forEach(el=>el.addEventListener('input',draw));
  window.addEventListener('resize',draw);
  form.addEventListener('submit',withButton(form,'Cropping…',async()=>{const f=fileIn.files[0];if(!f||!img)throw new Error('Please select an image file.');const r=rect();let ow=r.w,oh=r.h;const want=Number(form.elements.outw.value);if(want){if(!Number.isInteger(want)||want<16||want>8000)throw new Error('Enter an output width between 16 and 8000 pixels.');ow=want;oh=Math.max(1,Math.round(want*r.h/r.w))}checkSize(ow,oh);const fmt=form.elements.format.value,type=typeOf(fmt);const c=document.createElement('canvas');c.width=ow;c.height=oh;const ctx=c.getContext('2d',{alpha:type!=='image/jpeg'});if(type==='image/jpeg'){ctx.fillStyle='#fff';ctx.fillRect(0,0,ow,oh)}ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(img,r.x,r.y,r.w,r.h,0,0,ow,oh);const b=await toBlob(c,type,fmt==='PNG'?1:.94);offer(b,`${base(f.name)}-crop.${extOf(fmt)}`,`Done · ${ow}×${oh}px · ${kb(b.size)}`)}));
}

/* ---------- EXIF removal ---------- */
function initExif(){
  const form=$('#toolForm');
  form.addEventListener('submit',withButton(form,'Processing…',async()=>{const files=[...form.elements.files.files];if(!files.length)throw new Error('Please select an image file.');if(files.length>50)throw new Error('You can process up to 50 images at a time.');const outs=[];for(let i=0;i<files.length;i++){const f=files[i];if(files.length>1)showInfo(`Processing · ${i+1}/${files.length}`);const img=await decodeImage(f);const {w,h}=dims(img);checkSize(w,h);const fmt=sameFormat(f),type=typeOf(fmt);const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d',{alpha:type!=='image/jpeg'});if(type==='image/jpeg'){ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h)}ctx.drawImage(img,0,0);if(img.close)img.close();const b=await toBlob(c,type,fmt==='PNG'?1:.95);outs.push({b,name:`${base(f.name)}-clean.${extOf(fmt)}`})}if(outs.length===1){offer(outs[0].b,outs[0].name,`Done · removed location and camera metadata · ${kb(outs[0].b.size)}`);return}await loadLib('jszip');const zip=new JSZip(),used=new Set();outs.forEach(o=>zip.file(uniqueName(used,o.name),o.b));const z=await zip.generateAsync({type:'blob'});offer(z,'photos-clean.zip',`Done · removed metadata from ${outs.length} images and saved them in a ZIP file · ${kb(z.size)}`)}));
}

/* ---------- PDF rotation ---------- */
function parsePages(text,count){const out=new Set();for(const raw of text.split(',')){const part=raw.trim();if(!part)continue;const m=part.match(/^(\d+)(?:\s*-\s*(\d+))?$/);if(!m)throw new Error(`Invalid page format: ${part}`);const a=Number(m[1]),b=Number(m[2]||m[1]);if(a>b)throw new Error(`Enter page ranges from the smaller number to the larger number: ${part}`);if(a<1||b>count)throw new Error(`Check the page range. This PDF has ${count} pages.`);for(let n=a;n<=b;n++)out.add(n-1)}if(!out.size)throw new Error('No valid pages were selected.');return[...out]}
function initPdfRotate(){
  const form=$('#toolForm');
  form.addEventListener('submit',withButton(form,'Rotating…',async()=>{const f=form.elements.files.files[0];if(!f)throw new Error('Please select a PDF file.');const head=new Uint8Array(await f.slice(0,1024).arrayBuffer());if(!String.fromCharCode(...head).includes('%PDF-'))throw new Error('Please select a valid PDF file.');await loadLib('pdfLib');let doc;try{doc=await PDFLib.PDFDocument.load(await f.arrayBuffer(),{ignoreEncryption:false})}catch(e){throw new Error('Could not open the PDF. It may be password-protected or damaged.')}const pages=doc.getPages(),angle=Number(form.elements.angle.value)||90;const txt=form.elements.pages.value.trim();const idx=txt?parsePages(txt,pages.length):pages.map((_,i)=>i);for(const i of idx){const p=pages[i];const cur=(p.getRotation()?.angle)||0;p.setRotation(PDFLib.degrees(((cur+angle)%360+360)%360))}const b=new Blob([await doc.save()],{type:'application/pdf'});offer(b,`${base(f.name)}-rotated.pdf`,`Done · rotated ${idx.length} pages by ${angle}° · ${kb(b.size)}`)}));
}

/* ---------- video (GIF · audio) ---------- */
const MAX_VIDEO=200_000_000;
const FF_API=['https://unpkg.com/@ffmpeg/ffmpeg@0.11.6/dist/ffmpeg.min.js','https://cdn.jsdelivr.net/npm/@ffmpeg/ffmpeg@0.11.6/dist/ffmpeg.min.js'];
const FF_CORE=['https://unpkg.com/@ffmpeg/core-st@0.11.1/dist/ffmpeg-core.js','https://cdn.jsdelivr.net/npm/@ffmpeg/core-st@0.11.1/dist/ffmpeg-core.js'];
let ff=null;
function progress(ratio,msg){const wrap=$('#videoProgress'),bar=$('#videoProgressBar'),text=$('#videoProgressText');if(wrap)wrap.hidden=false;const p=Math.max(0,Math.min(100,Math.round((Number(ratio)||0)*100)));if(bar)bar.style.width=p+'%';if(text)text.textContent=`${msg} · ${p}%`}
async function ensureFF(){if(ff?.isLoaded?.())return ff;showInfo('Preparing the video engine for the first time. About 25MB of conversion components will be downloaded once.');progress(0,'Preparing engine');if(!(window.FFmpeg?.createFFmpeg)){let ok=false;for(const u of FF_API){try{await loadScript(u);if(window.FFmpeg?.createFFmpeg){ok=true;break}}catch(_){}}if(!ok)throw new Error('Could not load the video conversion module. Check your network connection.')}for(const corePath of FF_CORE){try{const inst=FFmpeg.createFFmpeg({mainName:'main',corePath,log:false,progress:({ratio})=>progress(ratio,'Converting')});await inst.load();ff=inst;return ff}catch(e){console.warn('FFmpeg core load failed',corePath,e)}}throw new Error('Could not start the video engine. Please try again shortly.')}
function rm(engine,...names){for(const n of names){try{engine.FS('unlink',n)}catch(_){}}}
function vext(name){return(String(name).split('.').pop()||'mp4').toLowerCase().replace(/[^a-z0-9]/g,'')||'mp4'}
async function runVideo(form,build){const f=form.elements.files.files[0];if(!f)throw new Error('Please select a video file.');if(f.size>MAX_VIDEO)throw new Error('For reliable browser processing, files must be 200MB or smaller.');const engine=await ensureFF();const stamp=Date.now(),input=`in-${stamp}.${vext(f.name)}`;engine.FS('writeFile',input,await FFmpeg.fetchFile(f));try{progress(0,'Converting');return await build(engine,input,f,stamp)}finally{rm(engine,input)}}
function initGif(){
  const form=$('#toolForm');
  form.addEventListener('submit',withButton(form,'Converting…',async()=>{const start=Number(form.elements.start.value||0),dur=Number(form.elements.duration.value||5);if(!(start>=0))throw new Error('Check the start time.');if(!(dur>0&&dur<=15))throw new Error('Enter a GIF duration greater than 0 and no more than 15 seconds.');const width=[240,320,480,640].includes(Number(form.elements.width.value))?Number(form.elements.width.value):480;const fps=[8,10,15].includes(Number(form.elements.fps.value))?Number(form.elements.fps.value):10;try{await runVideo(form,async(engine,input,f,stamp)=>{const out=`out-${stamp}.gif`;try{await engine.run('-ss',String(start),'-t',String(dur),'-i',input,'-vf',`fps=${fps},scale=${width}:-1:flags=lanczos,split[a][b];[a]palettegen=stats_mode=diff[p];[b][p]paletteuse=dither=bayer:bayer_scale=4`,'-loop','0',out);const data=engine.FS('readFile',out);if(!data?.length)throw new Error('empty');const b=new Blob([data],{type:'image/gif'});progress(1,'Done');offer(b,`${base(f.name)}.gif`,`Done · ${width}px · ${fps}fps · ${dur}s · ${(b.size/1_000_000).toFixed(2)}MB`)}finally{rm(engine,out)}})}catch(err){progress(0,'Failed');if(err?.message&&err.message!=='empty')throw err;throw new Error('GIF conversion failed. Make sure the start time is within the video, then try a shorter clip or smaller width.')}}));
}
function initMp3(){
  const form=$('#toolForm');
  form.addEventListener('submit',withButton(form,'Extracting…',async()=>{const fmt=form.elements.format.value==='M4A'?'m4a':'mp3';const br=['128k','192k','320k'].includes(form.elements.bitrate.value)?form.elements.bitrate.value:'192k';try{await runVideo(form,async(engine,input,f,stamp)=>{const tryEncode=async(kind)=>{const out=`out-${stamp}.${kind}`;try{const args=kind==='mp3'?['-i',input,'-vn','-map','0:a:0','-c:a','libmp3lame','-b:a',br,out]:['-i',input,'-vn','-map','0:a:0','-c:a','aac','-b:a',br==='320k'?'256k':br,out];await engine.run(...args);const d=engine.FS('readFile',out);return d?.length?d:null}catch(_){return null}finally{rm(engine,out)}};let kind=fmt,data=await tryEncode(kind);if(!data&&kind==='mp3'){kind='m4a';data=await tryEncode(kind)}if(!data)throw new Error('empty');const b=new Blob([data],{type:kind==='mp3'?'audio/mpeg':'audio/mp4'});progress(1,'Done');offer(b,`${base(f.name)}.${kind}`,`Done · ${kind.toUpperCase()} ${br.replace('k','kbps')} · ${(b.size/1_000_000).toFixed(2)}MB${kind!==fmt?' (saved as M4A because the MP3 encoder was unavailable)':''}`)})}catch(err){progress(0,'Failed');if(err?.message&&err.message!=='empty')throw err;throw new Error('Could not extract audio. The video may have no audio track or may use an unsupported codec.')}}));
}

const INIT={crop:initCrop,exif:initExif,pdfrotate:initPdfRotate,vgif:initGif,vmp3:initMp3};
if(INIT[TOOL])INIT[TOOL]();
window.addEventListener('beforeunload',clearUrl);
})();
