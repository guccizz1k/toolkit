(()=>{
'use strict';
const $=s=>document.querySelector(s);
let ffmpeg=null,currentUrl=null;
const MAX_FILE_BYTES=200_000_000;
const FFMPEG_SCRIPT_URLS=[
  'https://unpkg.com/@ffmpeg/ffmpeg@0.11.6/dist/ffmpeg.min.js',
  'https://cdn.jsdelivr.net/npm/@ffmpeg/ffmpeg@0.11.6/dist/ffmpeg.min.js'
];
const CORE_URLS=[
  'https://unpkg.com/@ffmpeg/core-st@0.11.1/dist/ffmpeg-core.js',
  'https://cdn.jsdelivr.net/npm/@ffmpeg/core-st@0.11.1/dist/ffmpeg-core.js'
];
function result(msg,err=false){const el=$('#result');if(!el)return;el.className='result'+(err?' error':'');el.innerHTML=msg;}
function safeBase(name){return (name||'video').replace(/\.[^.]+$/,'').replace(/[\\/:*?"<>|]+/g,'-').slice(0,100)||'video';}
function ext(name){return (name.split('.').pop()||'mp4').toLowerCase().replace(/[^a-z0-9]/g,'')||'mp4';}
function progress(ratio,msg='변환 중'){const wrap=$('#videoProgress'),bar=$('#videoProgressBar'),text=$('#videoProgressText');if(wrap)wrap.hidden=false;const p=Math.max(0,Math.min(100,Math.round((Number(ratio)||0)*100)));if(bar)bar.style.width=p+'%';if(text)text.textContent=`${msg} · ${p}%`;}
function loadScriptOnce(src){return new Promise((res,rej)=>{const old=document.querySelector(`script[data-toolkit-src="${src}"]`);if(old){if(old.dataset.loaded==='1')return res();old.addEventListener('load',res,{once:true});old.addEventListener('error',()=>rej(new Error('load failed')),{once:true});return;}const s=document.createElement('script');s.src=src;s.async=true;s.dataset.toolkitSrc=src;s.onload=()=>{s.dataset.loaded='1';res();};s.onerror=()=>{s.remove();rej(new Error('load failed'));};document.head.appendChild(s);});}
async function ensureFFmpegApi(){if(window.FFmpeg?.createFFmpeg&&window.FFmpeg?.fetchFile)return;let lastErr;for(const src of FFMPEG_SCRIPT_URLS){try{await loadScriptOnce(src);if(window.FFmpeg?.createFFmpeg&&window.FFmpeg?.fetchFile)return;}catch(e){lastErr=e;}}console.warn('FFmpeg API load error',lastErr);throw new Error('동영상 변환 모듈을 불러오지 못했습니다. 네트워크 상태를 확인해 주세요.');}
async function ensureFFmpeg(){if(ffmpeg?.isLoaded?.())return ffmpeg;result('동영상 엔진을 처음 준비하고 있습니다. 약 25MB의 변환 엔진을 한 번 불러옵니다.');progress(0,'엔진 준비');await ensureFFmpegApi();let lastErr;for(const corePath of CORE_URLS){try{const instance=FFmpeg.createFFmpeg({mainName:'main',corePath,log:false,progress:({ratio})=>progress(ratio,'변환 중')});await instance.load();ffmpeg=instance;return ffmpeg;}catch(e){console.warn('FFmpeg core load failed:',corePath,e);lastErr=e;}}console.warn('FFmpeg core load error',lastErr);throw new Error('동영상 엔진을 시작하지 못했습니다. 잠시 후 다시 시도해 주세요.');}
function scaleFilter(maxDim){const m=Number(maxDim);if(!Number.isFinite(m)||m<2)return null;return `scale='if(gt(iw,ih),min(${m},iw),-2)':'if(gt(iw,ih),-2,min(${m},ih))'`;}
function cleanup(engine,...names){for(const name of names){try{engine.FS('unlink',name);}catch(_){}}}
async function submit(e){
  e.preventDefault();
  const form=e.currentTarget,btn=form.querySelector('.primary'),file=form.elements.files.files[0];
  if(!file)return result('동영상 파일을 선택해 주세요.',true);
  if(file.size>MAX_FILE_BYTES)return result('안정적인 브라우저 변환을 위해 200MB 이하 파일만 지원합니다. 큰 영상은 먼저 길이를 줄이거나 PC용 편집 프로그램을 이용해 주세요.',true);
  const format=(form.elements.format.value||'mp4').toLowerCase();
  if(!['mp4','webm'].includes(format))return result('출력 형식은 MP4 또는 WEBM을 선택해 주세요.',true);
  const quality=form.elements.quality.value;
  const sizeValue=form.elements.size.value;
  const maxDim=sizeValue==='source'?null:Number(sizeValue);
  const old=btn.textContent;btn.disabled=true;btn.textContent='변환 중…';
  let input='',output='';
  try{
    const engine=await ensureFFmpeg();
    input=`input-${Date.now()}.${ext(file.name)}`;
    output=`output-${Date.now()}.${format}`;
    cleanup(engine,input,output);
    engine.FS('writeFile',input,await FFmpeg.fetchFile(file));
    const args=['-i',input,'-map','0:v:0','-map','0:a?','-sn','-dn'];
    const vf=scaleFilter(maxDim);if(vf)args.push('-vf',vf);
    if(format==='mp4'){
      const crf={high:'20',balanced:'25',small:'30'}[quality]||'25';
      args.push('-c:v','libx264','-preset','ultrafast','-crf',crf,'-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',output);
    }else{
      const crf={high:'28',balanced:'34',small:'40'}[quality]||'34';
      args.push('-c:v','libvpx','-deadline','realtime','-cpu-used','8','-crf',crf,'-b:v','0','-c:a','libvorbis','-q:a','4',output);
    }
    progress(0,'변환 중');
    await engine.run(...args);
    const data=engine.FS('readFile',output);
    if(!data?.length)throw new Error('변환된 파일이 비어 있습니다. 다른 출력 형식으로 다시 시도해 주세요.');
    const blob=new Blob([data],{type:format==='mp4'?'video/mp4':'video/webm'});
    if(currentUrl)URL.revokeObjectURL(currentUrl);currentUrl=URL.createObjectURL(blob);
    const res=$('#result');res.className='result';
    const newSize=(blob.size/1_000_000).toFixed(2),orig=(file.size/1_000_000).toFixed(2);
    const dimtxt=maxDim?`긴 변 최대 ${maxDim}px`:'원본 해상도 유지';
    res.innerHTML=`완료 · ${dimtxt} · ${orig}MB → ${newSize}MB<br><a class="download-btn" href="${currentUrl}" download="${safeBase(file.name)}-converted.${format}">변환 영상 저장</a>`;
    progress(1,'완료');
    cleanup(engine,input,output);
  }catch(err){
    console.error(err);
    if(ffmpeg)cleanup(ffmpeg,input,output);
    const fallback='동영상 변환에 실패했습니다. 지원되지 않는 코덱이거나 기기 메모리가 부족할 수 있습니다. 더 작은 파일 또는 다른 출력 형식으로 다시 시도해 주세요.';
    result(err?.message||fallback,true);progress(0,'실패');
  }finally{btn.disabled=false;btn.textContent=old;}
}
$('#toolForm')?.addEventListener('submit',submit);
window.addEventListener('beforeunload',()=>{if(currentUrl)URL.revokeObjectURL(currentUrl);});
})();
