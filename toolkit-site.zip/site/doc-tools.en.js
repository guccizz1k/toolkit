(()=>{
'use strict';
const $=s=>document.querySelector(s);
let currentUrl=null;
const DOC_LIMIT=50_000_000;
function result(msg,err=false){const el=$('#result');if(!el)return;el.className='result'+(err?' error':'');el.innerHTML=msg;}
function clearDownload(){if(currentUrl){URL.revokeObjectURL(currentUrl);currentUrl=null;}}
function safeBase(name){return (name||'converted').replace(/\.[^.]+$/,'').replace(/[\\/:*?"<>|]+/g,'-').slice(0,100)||'converted';}
function download(blob,name,detail=''){clearDownload();currentUrl=URL.createObjectURL(blob);result(`${detail?detail+'<br>':''}<a class="download-btn" href="${currentUrl}" download="${name}">Save output file</a>`);}
function ext(name){return (name.split('.').pop()||'').toLowerCase();}
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function htmlToText(html){const d=document.createElement('div');d.innerHTML=html;return d.textContent||d.innerText||'';}
function ensureSize(file){if(file.size>DOC_LIMIT)throw new Error('For reliable browser processing, document files must be 50MB or smaller.');}
function loadScript(src){return new Promise((resolve,reject)=>{const found=[...document.scripts].find(s=>s.src===src);if(found){if(found.dataset.loaded==='1'||found.readyState==='complete')return resolve();found.addEventListener('load',resolve,{once:true});found.addEventListener('error',()=>reject(new Error('load failed')),{once:true});return;}const s=document.createElement('script');s.src=src;s.async=true;s.onload=()=>{s.dataset.loaded='1';resolve();};s.onerror=()=>{s.remove();reject(new Error('load failed'));};document.head.appendChild(s);});}
async function ensureGlobal(name,urls,errorMessage){if(window[name])return window[name];for(const url of urls){try{await loadScript(url);if(window[name])return window[name];}catch(e){console.warn(`${name} load failed`,url,e);}}throw new Error(errorMessage);}
async function ensureXLSX(){return ensureGlobal('XLSX',[
  'https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js'
],'Could not load the spreadsheet conversion module. Check your network connection.');}
async function ensureMammoth(){return ensureGlobal('mammoth',[
  'https://cdn.jsdelivr.net/npm/mammoth@1.12.3/mammoth.browser.min.js',
  'https://unpkg.com/mammoth@1.12.3/mammoth.browser.min.js'
],'Could not load the Word conversion module. Check your network connection.');}
async function ensureJSZip(){return ensureGlobal('JSZip',[
  'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js',
  'https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js'
],'Could not load the HWPX processing module. Check your network connection.');}
let hwpModuleCache=null;
async function hwpModule(){
  if(hwpModuleCache)return hwpModuleCache;
  const urls=[
    'https://esm.sh/@ohah/hwpjs@0.1.0-rc.10?bundle',
    'https://cdn.jsdelivr.net/npm/@ohah/hwpjs@0.1.0-rc.10/+esm'
  ];
  for(const url of urls){try{const mod=await import(url);if(mod?.toHtml||mod?.toMarkdown){hwpModuleCache=mod;return mod;}}catch(e){console.warn('HWP module load failed',url,e);}}
  throw new Error('Could not load the HWP conversion module. Check your network connection or try an HWPX file.');
}
async function hwpxText(file){
  const Zip=await ensureJSZip();
  const zip=await Zip.loadAsync(await file.arrayBuffer());
  const defaultNames=Object.keys(zip.files).filter(n=>/^Contents\/section\d+\.xml$/i.test(n)).sort((a,b)=>{const na=+(a.match(/section(\d+)/i)||[,0])[1],nb=+(b.match(/section(\d+)/i)||[,0])[1];return na-nb;});
  let names=defaultNames;
  const hpfEntry=zip.file('Contents/content.hpf');
  if(hpfEntry){
    try{
      const hpfXml=await hpfEntry.async('text'),hpfDoc=new DOMParser().parseFromString(hpfXml,'application/xml');
      if(!hpfDoc.querySelector('parsererror')){
        const manifest=new Map();
        for(const el of [...hpfDoc.getElementsByTagName('*')].filter(el=>el.localName==='item')){
          const id=el.getAttribute?.('id'),href=el.getAttribute?.('href');
          if(id&&href)manifest.set(id,href);
        }
        const ordered=[];
        for(const ref of [...hpfDoc.getElementsByTagName('*')].filter(el=>el.localName==='itemref')){
          const idref=ref.getAttribute?.('idref'),href=idref?manifest.get(idref):null;
          if(!href)continue;
          let path=href.replace(/^\.\//,'').replace(/^\//,'');
          if(!path.startsWith('Contents/'))path='Contents/'+path;
          if(/^Contents\/section\d+\.xml$/i.test(path)&&zip.files[path])ordered.push(path);
        }
        if(ordered.length)names=ordered;
      }
    }catch(e){console.warn('HWPX spine parse fallback',e);}
  }
  if(!names.length)throw new Error('Could not find HWPX document content. The file may be damaged or use an unsupported HWPX structure.');
  const paras=[];
  for(const name of names){
    const entry=zip.file(name);if(!entry)continue;
    const xml=await entry.async('text');
    const doc=new DOMParser().parseFromString(xml,'application/xml');
    if(doc.querySelector('parsererror'))continue;
    const ps=[...doc.getElementsByTagName('*')].filter(el=>el.localName==='p');
    for(const p of ps){const ts=[...p.getElementsByTagName('*')].filter(el=>el.localName==='t').map(el=>el.textContent||'').join('');if(ts.trim())paras.push(ts);}
  }
  if(!paras.length)throw new Error('Could not read body text from the HWPX file.');
  return paras;
}
async function handleExcel(form){
  const file=form.elements.files.files[0];if(!file)throw new Error('Please select an Excel or CSV file.');ensureSize(file);
  const XLSX=await ensureXLSX();
  const wb=XLSX.read(await file.arrayBuffer(),{type:'array',cellDates:true});
  if(!wb.SheetNames?.length)throw new Error('No worksheets were found. Check whether the file is damaged.');
  const out=form.elements.format.value,base=safeBase(file.name);
  if(!['XLSX','CSV','ODS','HTML'].includes(out))throw new Error('Unsupported output format.');
  if(out==='XLSX'||out==='ODS'){
    const bookType=out.toLowerCase(),data=XLSX.write(wb,{bookType,type:'array'});
    download(new Blob([data],{type:out==='XLSX'?'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':'application/vnd.oasis.opendocument.spreadsheet'}),`${base}.${bookType}`,`Done · preserved ${wb.SheetNames.length} worksheets`);return;
  }
  const ws=wb.Sheets[wb.SheetNames[0]];
  if(!ws)throw new Error('Could not read the first worksheet.');
  if(out==='CSV'){
    const csv=XLSX.utils.sheet_to_csv(ws);
    download(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'}),`${base}.csv`,`Done · converted the first worksheet (${escapeHtml(wb.SheetNames[0])}) to CSV`);return;
  }
  const table=XLSX.utils.sheet_to_html(ws);
  const html=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${escapeHtml(base)}</title><style>body{font-family:sans-serif;padding:20px;overflow:auto}table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:6px;white-space:nowrap}</style></head><body>${table}</body></html>`;
  download(new Blob([html],{type:'text/html;charset=utf-8'}),`${base}.html`,'Done · converted the first worksheet to an HTML table');
}
async function handleWord(form){
  const file=form.elements.files.files[0];if(!file)throw new Error('Please select a DOCX file.');ensureSize(file);
  if(ext(file.name)!=='docx')throw new Error('The Word converter currently supports DOCX files.');
  const mammoth=await ensureMammoth(),buffer=await file.arrayBuffer(),out=form.elements.format.value,base=safeBase(file.name);
  if(out==='TXT'){
    const r=await mammoth.extractRawText({arrayBuffer:buffer});
    download(new Blob([r.value||''],{type:'text/plain;charset=utf-8'}),`${base}.txt`,`Done · extracted Word document text${r.messages?.length?` · ${r.messages.length} notices`:''}`);return;
  }
  if(out!=='HTML')throw new Error('Unsupported output format.');
  const r=await mammoth.convertToHtml({arrayBuffer:buffer});
  const html=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${escapeHtml(base)}</title><style>body{max-width:850px;margin:40px auto;padding:0 20px;font-family:sans-serif;line-height:1.65}img{max-width:100%;height:auto}table{border-collapse:collapse;max-width:100%}td,th{border:1px solid #ddd;padding:6px}</style></head><body>${r.value||''}</body></html>`;
  download(new Blob([html],{type:'text/html;charset=utf-8'}),`${base}.html`,`Done · converted the Word document to HTML${r.messages?.length?` · ${r.messages.length} notices`:''}`);
}
async function handleHwp(form){
  const file=form.elements.files.files[0];if(!file)throw new Error('Please select an HWP or HWPX file.');ensureSize(file);
  const e=ext(file.name),out=form.elements.format.value,base=safeBase(file.name);let html='',markdown='',text='';
  if(!['HTML','TXT','MARKDOWN'].includes(out))throw new Error('Unsupported output format.');
  if(e==='hwpx'){
    const paras=await hwpxText(file);text=paras.join('\n\n');markdown=text;html=paras.map(p=>`<p>${escapeHtml(p)}</p>`).join('\n');
  }else if(e==='hwp'){
    const mod=await hwpModule(),data=new Uint8Array(await file.arrayBuffer());
    if(out==='MARKDOWN'&&typeof mod.toMarkdown==='function'){
      const r=await mod.toMarkdown(data,{image:'base64',useHtml:true});markdown=r?.markdown||r?.value||String(r||'');
    }else if(typeof mod.toHtml==='function'){
      const r=await mod.toHtml(data,{includeVersion:false});html=typeof r==='string'?r:(r?.html||String(r||''));
    }else if(typeof mod.toMarkdown==='function'){
      const r=await mod.toMarkdown(data,{image:'base64',useHtml:true});markdown=r?.markdown||'';html=`<pre>${escapeHtml(markdown)}</pre>`;
    }else throw new Error('No compatible conversion API was found in the current HWP module.');
    if(!text)text=html?htmlToText(html):markdown.replace(/[#*_`>-]/g,' ');
  }else throw new Error('Please select an HWP or HWPX file.');
  if(out==='TXT'){
    if(!text)text=html?htmlToText(html):markdown;
    download(new Blob([text],{type:'text/plain;charset=utf-8'}),`${base}.txt`,'Done · extracted HWP/HWPX content to TXT');return;
  }
  if(out==='MARKDOWN'){
    if(!markdown)markdown=text||htmlToText(html);
    download(new Blob([markdown],{type:'text/markdown;charset=utf-8'}),`${base}.md`,'Done · extracted HWP/HWPX content to Markdown');return;
  }
  if(!html)html=(text||markdown).split(/\n{2,}/).map(p=>`<p>${escapeHtml(p)}</p>`).join('\n');
  const looksComplete=/<!doctype\s+html|<html[\s>]/i.test(html);
  const page=looksComplete?html:`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${escapeHtml(base)}</title><style>body{max-width:850px;margin:40px auto;padding:0 20px;font-family:sans-serif;line-height:1.65}img{max-width:100%;height:auto}table{border-collapse:collapse;max-width:100%}td,th{border:1px solid #ddd;padding:6px}</style></head><body>${html}</body></html>`;
  download(new Blob([page],{type:'text/html;charset=utf-8'}),`${base}.html`,'Done · converted the HWP/HWPX document to HTML');
}
async function submit(e){e.preventDefault();const form=e.currentTarget,btn=form.querySelector('.primary');const old=btn.textContent;btn.disabled=true;btn.textContent='Converting…';result('Reading the file…');try{const id=document.body.dataset.tool;if(id==='excel')await handleExcel(form);else if(id==='word')await handleWord(form);else if(id==='hwp')await handleHwp(form);else throw new Error('Unsupported document tool.');}catch(err){console.error(err);result(err?.message||'Conversion failed.',true);}finally{btn.disabled=false;btn.textContent=old;}}
$('#toolForm')?.addEventListener('submit',submit);
window.addEventListener('beforeunload',clearDownload);
})();
