# 변경 사항 (2026-09-30)

## 새로 추가한 파일
- og-image.png — 카톡·SNS 공유 미리보기 이미지 (1200×630)
- extra-tools.js — 새 도구 5종 전용 스크립트 (기존 JS와 분리)
- image-crop/ — 이미지 자르기 (증명사진 3:4, 여권, 1:1, 16:9 등 + 미리보기)
- exif-remove/ — 사진 위치정보(EXIF) 지우기 (여러 장 → ZIP)
- pdf-rotate/ — PDF 회전 (전체 또는 지정 페이지)
- video-to-gif/ — 동영상 GIF 변환 (최대 15초)
- video-to-mp3/ — 동영상 MP3/M4A 추출

## 기존 파일에서 바꾼 부분
- 모든 페이지 head: og:image, twitter:image 추가 / twitter:card → summary_large_image
- index.html: 도구 수 21개, 새 도구 카드 5개, 하단 소개글 교체, 워드·한글 카드 이름 명확화, NEW 배지 만료일 추가
- home.js: 맨 아래에 NEW 배지 자동 만료 코드 추가
- toolkit.js: 이미지 압축 부분만 수정 — 여러 장 선택 시 ZIP 저장 (1장일 때는 기존과 동일)
- image-compress: 여러 장 선택, 투명 PNG 안내, FAQ 2개 추가
- excel/word/hwp/video: 개인정보 안내 문구 통일, 관련 도구의 자기 자신 링크 교체
- word/hwp: PDF 변환 미지원 안내 추가
- pdf-merge, pdf-split: 관련 도구에 PDF 회전 링크
- about: 제공 기능 목록 갱신
- sitemap.xml: 새 페이지 5개 추가
- style.css: 맨 아래에 자르기 미리보기 스타일 추가
