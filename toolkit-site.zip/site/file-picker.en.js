(()=>{
  'use strict';
  const init=()=>{
    document.querySelectorAll('.file-picker-drop input[type="file"]').forEach(input=>{
      const drop=input.closest('.file-picker-drop');
      if(!drop)return;
      const name=drop.querySelector('[data-file-name]');
      if(!name)return;
      const update=()=>{
        const files=Array.from(input.files||[]);
        if(!files.length){name.textContent='No file selected';return;}
        if(files.length===1){name.textContent=files[0].name;return;}
        name.textContent=`${files[0].name} + ${files.length-1} more`;
      };
      input.addEventListener('change',update);
      update();
    });
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});
  else init();
})();
