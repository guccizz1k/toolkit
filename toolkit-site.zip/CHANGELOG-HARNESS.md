# Harness Change Log

## 2026-09-30
- 기준 원본을 `toolkit-site.zip`으로 재설정.
- 기존 `site/` 파일은 바이트 단위로 보존.
- 개발 규칙, 빠른 검사, Playwright full 검사, GitHub Actions, release SHA 검증, 복구 문서를 추가.
- 최종 전달 파일명을 `toolkit-site.zip`으로 고정.
## 2026-09-30 site-wide language and alignment audit
- Corrected Korean spacing/wording across visible HTML, metadata and user-facing JS messages.
- Re-ran responsive alignment checks for 390/760/1280px viewports.
- No new paid service, data deletion, or public-access change.
