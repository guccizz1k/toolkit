# ZIP 직접 교체 규칙

- 최종 전달 파일명은 **toolkit-site.zip**이다.
- 기존 ZIP을 전부 풀어 새 프로젝트를 만드는 방식 대신 원본 ZIP 엔트리를 읽고 필요한 엔트리만 추가/교체한다.
- `site/`는 기존 경로 그대로 유지한다.
- ZIP 최상위에 `site/`, `AGENTS.md`, `package.json`, `scripts/`, `.github/`, `vercel.json`이 바로 위치한다.
- `toolkit/` 같은 추가 래퍼 폴더를 만들지 않는다.
- GitHub에는 ZIP 자체를 배포 파일로 쓰기보다 ZIP 안의 동일 경로 파일을 기존 저장소 경로에 교체한다.
- Vercel 출력 디렉터리는 `site`다.
