import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {ROOT,walk} from './common.mjs';

const site=path.join(ROOT,'site');
const base='https://www.toolkitsbox.com';
const htmlFiles=walk(site).filter(f=>f.endsWith('.html'));
function rel(f){return path.relative(site,f).replaceAll(path.sep,'/');}
function routeFor(relPath){if(relPath==='index.html')return '/';if(relPath.endsWith('/index.html'))return '/'+relPath.slice(0,-'index.html'.length);return '/'+relPath;}
function enRoute(route){return route==='/'?'/en/':'/en'+route;}
function koRoute(route){if(route==='/en/')return '/';return route.startsWith('/en/')?route.slice(3):route;}
function attr(s,tag,name){const m=s.match(new RegExp(`<${tag}\\b[^>]*\\b${name}=["']([^"']+)["'][^>]*>`,`i`));return m?.[1]||null;}
function linkHref(s,relValue,hreflang=null){for(const m of s.matchAll(/<link\b[^>]*>/gi)){const tag=m[0];if(!new RegExp(`\\brel=["']${relValue}["']`,'i').test(tag))continue;if(hreflang&&!new RegExp(`\\bhreflang=["']${hreflang}["']`,'i').test(tag))continue;const h=tag.match(/\bhref=["']([^"']+)["']/i);if(h)return h[1];}return null;}
const indexable=[];let pairs=0,enPages=0,koPages=0;
for(const f of htmlFiles){
  const r=rel(f); if(r.startsWith('google')||r==='404.html')continue;
  const s=fs.readFileSync(f,'utf8'); const route=routeFor(r); const isEn=r.startsWith('en/');
  assert.match(s,new RegExp(`<html[^>]+lang=["']${isEn?'en':'ko'}["']`,'i'),`${r}: wrong html lang`);
  const canonical=linkHref(s,'canonical');assert.ok(canonical,`${r}: canonical missing`);
  const expectedCanonical=base+route;assert.equal(canonical,expectedCanonical,`${r}: canonical mismatch`);
  const expectedKo=base+(isEn?koRoute(route):route); const expectedEn=base+(isEn?route:enRoute(route));
  assert.equal(linkHref(s,'alternate','ko'),expectedKo,`${r}: ko hreflang mismatch`);
  assert.equal(linkHref(s,'alternate','en'),expectedEn,`${r}: en hreflang mismatch`);
  assert.equal(linkHref(s,'alternate','x-default'),expectedEn,`${r}: x-default mismatch`);
  const counterpartRel=isEn?(koRoute(route)==='/'?'index.html':koRoute(route).replace(/^\//,'')+'index.html'):(enRoute(route)==='/en/'?'en/index.html':enRoute(route).replace(/^\//,'')+'index.html');
  assert.ok(fs.existsSync(path.join(site,counterpartRel)),`${r}: counterpart missing ${counterpartRel}`);pairs++;
  const title=(s.match(/<title>([\s\S]*?)<\/title>/i)||[])[1]?.replace(/<[^>]+>/g,'').trim();assert.ok(title,`${r}: title missing`);assert.ok(title.length<=80,`${r}: title too long (${title.length})`);
  const desc=(s.match(/<meta\b[^>]*name=["']description["'][^>]*content=["']([^"']*)["'][^>]*>/i)||s.match(/<meta\b[^>]*content=["']([^"']*)["'][^>]*name=["']description["'][^>]*>/i)||[])[1];assert.ok(desc,`${r}: description missing`);assert.ok(desc.length<=200,`${r}: description too long (${desc.length})`);
  if(isEn){enPages++;const cleaned=s.replaceAll('한국어','').replace(/<script[\s\S]*?<\/script>/gi,'').replace(/<style[\s\S]*?<\/style>/gi,'');assert.ok(!/[가-힣]/.test(cleaned),`${r}: untranslated Hangul remains on English page`);}else koPages++;
  const robots=(s.match(/<meta\b[^>]*name=["']robots["'][^>]*content=["']([^"']*)["'][^>]*>/i)||s.match(/<meta\b[^>]*content=["']([^"']*)["'][^>]*name=["']robots["'][^>]*>/i)||[])[1]||'';
  if(robots.split(',').map(x=>x.trim().toLowerCase()).includes('index'))indexable.push(canonical);
}
const sitemap=fs.readFileSync(path.join(site,'sitemap.xml'),'utf8');const locs=[...sitemap.matchAll(/<loc>([^<]+)<\/loc>/g)].map(m=>m[1]);
for(const u of indexable)assert.ok(locs.includes(u),`sitemap missing indexable URL ${u}`);
for(const u of locs)assert.ok(indexable.includes(u),`sitemap contains non-indexable or missing URL ${u}`);
assert.equal(new Set(locs).size,locs.length,'duplicate sitemap URLs');
console.log(JSON.stringify({status:'passed',englishPages:enPages,koreanPages:koPages,hreflangPairs:pairs,sitemapUrls:locs.length},null,2));
