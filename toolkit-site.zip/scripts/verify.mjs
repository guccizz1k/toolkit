import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {ROOT,siteFingerprint} from './common.mjs';

const full=process.argv.includes('--full'), before=siteFingerprint(), steps=[];
fs.mkdirSync(path.join(ROOT,'reports'),{recursive:true});
function run(name,cmd,args,timeout=120000){
 const r=spawnSync(cmd,args,{cwd:ROOT,encoding:'utf8',timeout});const ok=r.status===0&&!r.error;
 steps.push({name,status:ok?'passed':'failed',exit:r.status,error:r.error?.message||null});
 process.stdout.write(r.stdout||'');process.stderr.write(r.stderr||'');
 if(!ok)throw new Error(`${name} failed`);
}
let status='passed', error=null;
try{
 run('static',process.execPath,['scripts/static-check.mjs']);
 if(full)run('e2e',process.execPath,['scripts/e2e.mjs'],900000);
 run('npm-audit','npm',['audit','--json','--audit-level=high'],120000);
 if(before!==siteFingerprint())throw new Error('verification changed site files');
}catch(e){status='failed';error=String(e.message||e)}
const limitations=full?['Real iOS Safari not_run','Binary HWP success path not_run','Live production CDN/cache/ads not_run']:['Browser conversion suite not_run (use npm run verify:full)','Real iOS Safari not_run','Binary HWP success path not_run','Live production CDN/cache/ads not_run'];
fs.writeFileSync(path.join(ROOT,'reports','verification.json'),JSON.stringify({at:new Date().toISOString(),profile:full?'full':'standard',status,sourceFingerprint:before,steps,limitations,error},null,2)+'\n');
console.log(`verification ${status} (${full?'full':'standard'})`);
if(status!=='passed')process.exitCode=1;
