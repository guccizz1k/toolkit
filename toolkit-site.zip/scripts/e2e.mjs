import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
import {ROOT} from './common.mjs';

const site=path.join(ROOT,'site'), out=path.join(ROOT,'reports','e2e');
fs.mkdirSync(out,{recursive:true});
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.xml':'application/xml','.txt':'text/plain'};
const server=http.createServer((req,res)=>{
  const raw=decodeURIComponent(new URL(req.url,'http://x').pathname);
  let p=path.join(site,raw.replace(/^\/+/,''));
  if(raw.endsWith('/'))p=path.join(p,'index.html');
  if(!path.extname(p)&&fs.existsSync(path.join(p,'index.html')))p=path.join(p,'index.html');
  if(!p.startsWith(site)||!fs.existsSync(p)||fs.statSync(p).isDirectory()){res.statusCode=404;return res.end('404')}
  res.setHeader('content-type',mime[path.extname(p)]||'application/octet-stream');fs.createReadStream(p).pipe(res);
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const base=`http://127.0.0.1:${server.address().port}`;
const browser=await chromium.launch({headless:true});
const results=[];
async function test(name,fn){try{await fn();results.push({name,status:'passed'});console.log('PASS',name)}catch(e){results.push({name,status:'failed',error:String(e?.stack||e)});console.error('FAIL',name,e);throw e}}
const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAFElEQVR42mP8z8AARAwMjIwgAQAOHgIBxI4+ZQAAAABJRU5ErkJggg==','base64');
function pngSize(b){assert.equal(b.subarray(1,4).toString(),'PNG');return{w:b.readUInt32BE(16),h:b.readUInt32BE(20)}}
async function newPage(blockExternal=false){
 const context=await browser.newContext({acceptDownloads:true,viewport:{width:390,height:844}});
 const reqs=[];
 context.on('request',r=>reqs.push({method:r.method(),url:r.url(),post:r.postDataBuffer()?.length||0}));
 if(blockExternal)await context.route('**/*',route=>{const u=route.request().url();u.startsWith(base)?route.continue():route.abort()});
 const page=await context.newPage(); return {context,page,reqs};
}
try{
 await test('image-resize-output',async()=>{
   const {context,page,reqs}=await newPage();
   const t=Date.now();await page.goto(base+'/image-resize/');assert.ok(Date.now()-t<5000,'local page load >5s');
   await page.locator('input[type=file]').setInputFiles({name:'tiny.png',mimeType:'image/png',buffer:png});
   await page.locator('[name=width]').fill('16');await page.locator('[name=height]').fill('12');await page.locator('[name=format]').selectOption({label:'PNG'});
   await page.locator('.primary').click();await page.locator('#result .download-btn').waitFor();
   const [dl]=await Promise.all([page.waitForEvent('download'),page.locator('#result .download-btn').click()]);
   const p=path.join(out,'resize.png');await dl.saveAs(p);const b=fs.readFileSync(p),d=pngSize(b);assert.deepEqual(d,{w:16,h:12});assert.ok(reqs.every(r=>r.method==='GET'||r.url.startsWith('data:')||r.url.startsWith('blob:')),'unexpected write/upload request');await context.close();
 });
 await test('image-convert-jpeg-output',async()=>{
   const {context,page}=await newPage();await page.goto(base+'/image-convert/');
   await page.locator('input[type=file]').setInputFiles({name:'tiny.png',mimeType:'image/png',buffer:png});await page.locator('[name=format]').selectOption({label:'JPG'});
   await page.locator('.primary').click();await page.locator('#result .download-btn').waitFor();const [dl]=await Promise.all([page.waitForEvent('download'),page.locator('#result .download-btn').click()]);
   const p=path.join(out,'convert.jpg');await dl.saveAs(p);const b=fs.readFileSync(p);assert.equal(b[0],0xff);assert.equal(b[1],0xd8);assert.equal(b.at(-2),0xff);assert.equal(b.at(-1),0xd9);await context.close();
 });
 await test('image-compress-target',async()=>{
   const {context,page}=await newPage();await page.goto(base+'/image-compress/');
   await page.locator('input[type=file]').setInputFiles({name:'tiny.png',mimeType:'image/png',buffer:png});await page.locator('[name=target]').fill('10');await page.locator('[name=format]').selectOption({label:'JPG'});
   await page.locator('.primary').click();await page.locator('#result .download-btn').waitFor();const [dl]=await Promise.all([page.waitForEvent('download'),page.locator('#result .download-btn').click()]);
   const p=path.join(out,'compress.jpg');await dl.saveAs(p);const b=fs.readFileSync(p);assert.ok(b.length<=10000,`compressed ${b.length}>10000`);assert.equal(b[0],0xff);assert.equal(b[1],0xd8);await context.close();
 });
 await test('network-failure-recovers',async()=>{
   const {context,page}=await newPage(true);await page.goto(base+'/pdf-merge/');
   const pdf=Buffer.from('%PDF-1.4\n1 0 obj\n<<>>\nendobj\ntrailer\n<<>>\n%%EOF\n');
   await page.locator('input[type=file]').setInputFiles([{name:'a.pdf',mimeType:'application/pdf',buffer:pdf},{name:'b.pdf',mimeType:'application/pdf',buffer:pdf}]);
   await page.locator('.primary').click();await page.locator('#result.error').waitFor({timeout:10000});assert.equal(await page.locator('.primary').isDisabled(),false);assert.equal(await page.locator('#result .download-btn').count(),0);await context.close();
 });
 await test('large-document-rejected',async()=>{
   const {context,page}=await newPage();await page.goto(base+'/word-convert/');
   const size=50_000_001;await page.locator('input[type=file]').setInputFiles({name:'large.docx',mimeType:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',buffer:Buffer.alloc(size)});
   await page.locator('.primary').click();await page.locator('#result.error').waitFor({timeout:10000});assert.match(await page.locator('#result').innerText(),/50MB|50 MB|50,000,000/);assert.equal(await page.locator('.primary').isDisabled(),false);await context.close();
 });
 await test('responsive-overflow',async()=>{
   for(const width of [390,1440]){const context=await browser.newContext({viewport:{width,height:900}});const page=await context.newPage();for(const route of ['/','/image-compress/','/pdf-merge/','/word-convert/']){await page.goto(base+route);const s=await page.evaluate(()=>({inner:innerWidth,scroll:document.documentElement.scrollWidth}));assert.ok(s.scroll<=s.inner+1,`${route}@${width} overflow ${s.scroll}`)}await context.close()}
 });
}finally{
 fs.mkdirSync(path.join(ROOT,'reports'),{recursive:true});
 fs.writeFileSync(path.join(ROOT,'reports','e2e.json'),JSON.stringify({at:new Date().toISOString(),results},null,2)+'\n');
 await browser.close();server.close();
}
if(results.some(r=>r.status==='failed'))process.exitCode=1;
