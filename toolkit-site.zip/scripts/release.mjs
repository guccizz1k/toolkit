import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import JSZip from 'jszip';
import {ROOT,fileMap,sha256,siteFingerprint} from './common.mjs';
const dist=path.join(ROOT,'dist'), zipPath=path.join(dist,'toolkit-site.zip'), metaPath=path.join(dist,'RELEASE.json');
function expected(){return {...fileMap(path.join(ROOT,'site'),'site/'),'vercel.json':sha256(fs.readFileSync(path.join(ROOT,'vercel.json')))}}
async function inspect(){
 const z=await JSZip.loadAsync(fs.readFileSync(zipPath));const meta=JSON.parse(fs.readFileSync(metaPath,'utf8'));const got={};
 for(const [name,e] of Object.entries(z.files)){if(e.dir)continue;got[name]=sha256(await e.async('nodebuffer'))}
 assert.deepEqual(got,meta.files,'release ZIP differs from release manifest');
 assert.ok(z.file('site/index.html'),'site/index.html missing');assert.ok(z.file('vercel.json'),'vercel.json missing');
 const v=JSON.parse(await z.file('vercel.json').async('text'));assert.equal(v.outputDirectory,'site');
 return meta;
}
if(process.argv.includes('--check')){const m=await inspect();console.log('PASS release',m.archiveSha256);process.exit(0)}
const report=JSON.parse(fs.readFileSync(path.join(ROOT,'reports','verification.json'),'utf8'));
assert.equal(report.status,'passed','run verification first');assert.equal(report.profile,'full','release requires full verification');assert.equal(report.sourceFingerprint,siteFingerprint(),'site changed after verification');
const files=expected(), z=new JSZip();
for(const name of Object.keys(files).sort())z.file(name,fs.readFileSync(path.join(ROOT,name)),{date:new Date('2026-09-30T00:00:00Z')});
fs.mkdirSync(dist,{recursive:true});const bytes=await z.generateAsync({type:'nodebuffer',compression:'DEFLATE',compressionOptions:{level:9}});fs.writeFileSync(zipPath,bytes);
const meta={format:1,at:new Date().toISOString(),sourceFingerprint:report.sourceFingerprint,files,archiveSha256:sha256(bytes),limitations:report.limitations};
fs.writeFileSync(metaPath,JSON.stringify(meta,null,2)+'\n');await inspect();console.log('PASS packaged dist/toolkit-site.zip');
