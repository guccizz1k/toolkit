import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {ROOT,walk} from './common.mjs';

const site=path.join(ROOT,'site');
const policy=JSON.parse(fs.readFileSync(path.join(ROOT,'tests/policy.json'),'utf8'));
assert.ok(fs.existsSync(path.join(site,'index.html')),'site/index.html missing');
const files=walk(site), html=files.filter(f=>f.endsWith('.html')), js=files.filter(f=>f.endsWith('.js'));
const total=files.reduce((n,f)=>n+fs.statSync(f).size,0);
assert.ok(total<=policy.maxSiteBytes,`site too large: ${total}`);
for(const f of files)assert.ok(fs.statSync(f).size<=policy.maxAssetBytes,`asset too large: ${f}`);
for(const f of js){const r=spawnSync(process.execPath,['--check',f],{encoding:'utf8'});assert.equal(r.status,0,`${f}: ${r.stderr}`)}
let refs=0;
for(const f of html){
  const s=fs.readFileSync(f,'utf8'), rel=path.relative(site,f);
  if(!rel.startsWith('google')){
    assert.match(s,/<title>[\s\S]*?<\/title>/i,`${rel}: title missing`);
    assert.match(s,/name=["']viewport["']/i,`${rel}: viewport missing`);
    const expectedLang=rel.startsWith('en/')?'en':'ko';
    assert.match(s,new RegExp(`<html[^>]+lang=[\"']${expectedLang}[\"']`,'i'),`${rel}: lang=${expectedLang} missing`);
  }
  const ids=[...s.matchAll(/\bid=["']([^"']+)["']/gi)].map(m=>m[1]);
  assert.equal(new Set(ids).size,ids.length,`${rel}: duplicate id`);
  for(const m of s.matchAll(/(?:href|src)=["']([^"'#]+)["']/gi)){
    const u=m[1]; if(/^(https?:|mailto:|data:|blob:|javascript:)/i.test(u))continue;
    const clean=u.split(/[?#]/)[0]; if(!clean)continue;
    const target=u.startsWith('/')?path.join(site,clean.replace(/^\//,'')):path.resolve(path.dirname(f),clean);
    assert.ok(target.startsWith(site),`${rel}: unsafe path ${u}`);
    assert.ok(fs.existsSync(target),`${rel}: broken local ref ${u}`);
    refs++;
  }
}
const source=files.filter(f=>/\.(?:js|html)$/i.test(f)).map(f=>fs.readFileSync(f,'utf8')).join('\n');
assert.ok(!/\b(?:localStorage|indexedDB)\b/.test(source),'persistent browser storage added: privacy review required');
assert.ok(!/\b(?:eval\s*\(|new\s+Function\s*\()/.test(source),'dynamic code execution detected');
assert.ok(!/fetch\([\s\S]{0,300}?method\s*:\s*["'](?:POST|PUT|PATCH)["']/i.test(source),'network upload/write request detected');
const hosts=[...source.matchAll(/https?:\/\/([A-Za-z0-9.-]+)/g)].map(m=>m[1].toLowerCase());
for(const h of new Set(hosts))assert.ok(policy.allowedExternalHosts.includes(h),`unreviewed external host: ${h}`);
const v=JSON.parse(fs.readFileSync(path.join(ROOT,'vercel.json'),'utf8'));
assert.equal(v.outputDirectory,'site','Vercel outputDirectory must be site');
console.log(JSON.stringify({status:'passed',siteFiles:files.length,htmlPages:html.length,jsFiles:js.length,localRefs:refs,siteBytes:total,externalHosts:[...new Set(hosts)].sort()},null,2));
