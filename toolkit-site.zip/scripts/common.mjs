import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
export const ROOT=path.resolve(import.meta.dirname,'..');
export const sha256=b=>crypto.createHash('sha256').update(b).digest('hex');
export function walk(dir){if(!fs.existsSync(dir))return[];return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]).sort()}
export function fileMap(dir,prefix=''){return Object.fromEntries(walk(dir).map(p=>[(prefix+path.relative(dir,p)).split(path.sep).join('/'),sha256(fs.readFileSync(p))]))}
export function siteFingerprint(){return sha256(Buffer.from(JSON.stringify(fileMap(path.join(ROOT,'site'),'site/'))))}
