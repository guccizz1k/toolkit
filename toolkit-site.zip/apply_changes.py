from pathlib import Path
from bs4 import BeautifulSoup
from PIL import Image, ImageFilter
import numpy as np, cv2
p=Path('/mnt/data/toolkit_edit/site');h=p/'index.html';s=BeautifulSoup(h.read_text(), 'html.parser')
hero=s.select_one('.toolkit-brand-hero');hero.select_one('.hero-kicker').string='무료 파일 변환과 편집, 한 곳에서 간편하게'
# interactive accessible search suggestions with direct links
search=hero.select_one('.search');search['class'].append('toolkit-search-wrap')
search['role']='search';suggest=s.new_tag('div',id='toolSearchSuggestions',attrs={'class':'toolkit-search-suggestions','hidden':'','role':'listbox','aria-label':'검색 도구 추천'});search.append(suggest)
q=s.select_one('#toolSearch');q['aria-controls']='toolSearchSuggestions';q['aria-expanded']='false';q['autocomplete']='off';q['placeholder']='어떤 작업이 필요하세요? 예: 엑셀, PDF, 이미지'
# compact categories: keep links and accessibility, remove long secondary text
for c in s.select('.category-overview .category-card'):
    detail=c.select_one('small')
    if detail: detail.decompose()
# eliminate redundant lists below category overview, preserve useful guide section and main tool grid
for sel in ['#popular-searches','.category-quickbar','.trust-strip']:
    el=s.select_one(sel)
    if el:el.decompose()
# compact quick-start to one row by removing duplicate shortcuts (search suggestions replaces)
quick=s.select_one('.toolkit-quick-start')
if quick:quick.decompose()
# search JS gets versioned query for cache freshness
for script in s.find_all('script',src=True):
    if script['src'].split('?')[0].endswith('/home.js') or script['src'].split('?')[0]=='home.js':script['src']=script['src'].split('?')[0]+'?v=20261011-search2'
for link in s.find_all('link',href=True):
    if link['href'].split('?')[0] in ('/style.css','style.css'):link['href']=link['href'].split('?')[0]+'?v=20261011-ui2'
h.write_text(str(s),encoding='utf-8')
# GrabCut original photo, foreground is centrally positioned bear; remove entire studio background
im=Image.open('/mnt/data/IMG_6956.png').convert('RGB');rgb=np.array(im);bgr=cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR)
mask=np.zeros(bgr.shape[:2],np.uint8);mask[:,:]=cv2.GC_BGD
# center region, paws and ears with silhouette; avoid corners
cv2.ellipse(mask,(513,535),(298,465),0,0,360,cv2.GC_PR_FGD,-1)
cv2.ellipse(mask,(508,555),(212,360),0,0,360,cv2.GC_FGD,-1)
# seed outside body as background
bg=np.zeros((1,65),np.float64);fg=np.zeros((1,65),np.float64)
cv2.grabCut(bgr,mask,None,bg,fg,7,cv2.GC_INIT_WITH_MASK)
a=np.where((mask==cv2.GC_FGD)|(mask==cv2.GC_PR_FGD),255,0).astype('uint8')
# Keep largest foreground component; feather edges lightly
num,labels,stats,centroids=cv2.connectedComponentsWithStats(a,8)
idx=max(range(1,num),key=lambda i:stats[i,cv2.CC_STAT_AREA]);a=np.where(labels==idx,255,0).astype('uint8')
a=np.array(Image.fromarray(a).filter(ImageFilter.GaussianBlur(.9)))
out=Image.fromarray(np.dstack([rgb,a]),'RGBA');out.save(p/'toolkit-polar-bear.png',optimize=True)
mascot=s.select_one('.toolkit-mascot img');mascot['src']='/toolkit-polar-bear.png';mascot['alt']='윙크하며 엄지를 올리는 TOOLKIT 북극곰';h.write_text(str(s),encoding='utf-8')
# replace existing JS search with live suggestions, filtered results and enter navigation
js=p/'home.js';js.write_text('''(()=>{\n'use strict';\nconst q=document.getElementById('toolSearch');\nconst cards=[...document.querySelectorAll('.tool-card[data-search]')];\nconst sections=[...document.querySelectorAll('[data-category-section]')];\nconst count=document.getElementById('searchCount');\nconst empty=document.getElementById('searchEmpty');\nconst total=document.getElementById('toolTotal');\nconst pop=document.getElementById('toolSearchSuggestions');\nconst aliases={'엑셀':'document','excel':'document','워드':'document','word':'document','한글':'document','hwp':'document','pdf':'pdf','피디에프':'pdf','이미지':'image','사진':'image','동영상':'video','영상':'video','바코드':'code','qr':'code','글자':'text'};\nfunction normalize(s){return String(s||'').trim().toLocaleLowerCase('ko-KR');}\nfunction matching(term){return cards.filter(c=>{const hay=normalize(c.dataset.search||c.textContent);return hay.includes(term)||(aliases[term]&&c.dataset.cat===aliases[term]);});}\nfunction apply(){\n const term=normalize(q?.value);const matches=term?matching(term):cards;const set=new Set(matches);\n for(const c of cards)c.hidden=!set.has(c);\n for(const sec of sections)sec.hidden=![...sec.querySelectorAll('.tool-card')].some(c=>!c.hidden);\n if(count)count.textContent=term?`${matches.length}개 도구` : '';\n if(total)total.textContent=term?`검색 결과 ${matches.length}개`:`총 ${cards.length}개`;\n if(empty)empty.hidden=matches.length!==0;\n if(pop){pop.replaceChildren();if(term){\n  const caption=document.createElement('div');caption.className='toolkit-search-caption';caption.textContent=matches.length?'추천 도구 · 선택하면 바로 이동':'검색 결과가 없습니다';pop.append(caption);\n  for(const c of matches.slice(0,6)){const a=document.createElement('a');a.href=c.getAttribute('href');a.setAttribute('role','option');a.textContent=c.querySelector('strong')?.textContent?.trim()||'도구 바로가기';pop.append(a);}\n  if(matches.length>6){const more=document.createElement('button');more.type='button';more.textContent=`나머지 ${matches.length-6}개 결과 보기 ↓`;more.addEventListener('click',()=>{close();document.getElementById('all-tools')?.scrollIntoView({behavior:'smooth'});});pop.append(more);}\n }pop.hidden=!term;q?.setAttribute('aria-expanded',String(Boolean(term)));}\n return matches;\n}\nfunction close(){if(pop)pop.hidden=true;q?.setAttribute('aria-expanded','false');}\nq?.addEventListener('input',apply);\nq?.addEventListener('keydown',e=>{if(e.key==='Escape'){close();return;}if(e.key==='Enter'){e.preventDefault();const matches=apply();if(matches.length===1){window.location.assign(matches[0].getAttribute('href'));}else{close();document.getElementById('all-tools')?.scrollIntoView({behavior:'smooth'});}}});\ndocument.addEventListener('pointerdown',e=>{if(!e.target.closest('.toolkit-search-wrap'))close();});\nq?.addEventListener('focus',()=>{if(normalize(q.value))apply();});\ndocument.querySelectorAll('.category-card').forEach(a=>a.addEventListener('click',()=>{if(q&&q.value){q.value='';apply();close();}}));\n})();\n(()=>{const today=new Date().toISOString().slice(0,10);document.querySelectorAll('.new-badge[data-new-until]').forEach(b=>{if(b.dataset.newUntil<today)b.remove();});})();\n''',encoding='utf-8')
css=p/'style.css';css.write_text(css.read_text()+'''\n/* Compact home v2; search results are keyboard-accessible */\n.toolkit-brand-hero .toolkit-mascot{width:175px;height:188px;margin:0 auto 2px}\n.toolkit-brand-hero .toolkit-mascot img{width:100%;height:100%;object-fit:contain;mix-blend-mode:normal;border-radius:0}\n.toolkit-brand-hero .hero-kicker{background:#e7f0ff;color:#2555a2;font-size:14px;padding:9px 15px}\n.toolkit-search-wrap{position:relative;z-index:20}\n.toolkit-search-suggestions{position:absolute;top:calc(100% + 8px);left:0;right:0;z-index:100;background:#fff;border:1px solid #c8d8f2;border-radius:16px;padding:8px;box-shadow:0 18px 38px rgba(28,60,110,.16);max-height:340px;overflow:auto;text-align:left}\n.toolkit-search-suggestions[hidden]{display:none!important}\n.toolkit-search-caption{padding:8px 12px;color:#5b6c86;font-size:13px;font-weight:700}\n.toolkit-search-suggestions a,.toolkit-search-suggestions button{display:block;width:100%;text-align:left;background:transparent;border:0;border-radius:9px;padding:11px 13px;font-size:15px;font-weight:750;color:#203a64;text-decoration:none;cursor:pointer}\n.toolkit-search-suggestions a:hover,.toolkit-search-suggestions a:focus-visible,.toolkit-search-suggestions button:hover{background:#edf4ff;outline:2px solid transparent}\n.category-overview .category-cards{gap:10px!important}\n.category-overview .category-card{height:112px!important;min-height:112px!important;padding:13px 9px!important;gap:4px!important;border-radius:17px!important}\n.category-overview .category-card>.category-icon{width:39px!important;height:39px!important;flex:0 0 39px!important;font-size:21px!important;border-radius:12px!important}\n.category-overview .category-card b{font-size:16px!important;margin:6px 0 0!important;white-space:normal!important}\n.category-overview .category-card small{display:none!important}\n.category-overview{margin-top:24px}\n.toolkit-brand-promises{margin-top:17px}\n@media(max-width:520px){.toolkit-brand-hero{padding:20px 14px 22px}.toolkit-brand-hero .toolkit-mascot{width:145px;height:154px}.toolkit-brand-hero .hero-kicker{font-size:12px;padding:7px 11px}.category-overview .category-card{height:98px!important;min-height:98px!important}.category-overview .category-card b{font-size:15px!important}}\n''',encoding='utf-8')
print('edited',len(cards:=s.select('.tool-card')), 'tool cards; mascot', (p/'toolkit-polar-bear.png').stat().st_size)
