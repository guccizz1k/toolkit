# TOOLKIT Global SEO hardening

{
  "date": "2026-10-06",
  "changes": [
    "Expanded robots meta previews on indexable pages",
    "Added free Offer structured data to WebApplication entries",
    "Added BreadcrumbList structured data to existing how-to guides",
    "Strengthened root WebSite name identity with ToolkitsBox alternateName and publisher",
    "Made 404 recovery bilingual for international visitors",
    "Refreshed sitemap lastmod dates"
  ],
  "runtimeJsUnchanged": true,
  "changedFiles": 58
}
