TOOLKIT v6.1 pre-AdSense hardened build

Deploy this build to the EXISTING Vercel project:
https://toolkit-static-beta-v6.vercel.app

Do not create a new hostname for this ZIP unless canonical URLs, structured-data URLs, sitemap.xml and robots.txt are rebuilt for the new hostname.

Current state:
- Ads are disabled in ads-config.js.
- Core image/text behavior and all workflow paths have been regression-tested.
- SEO/internal links/sitemap/robots/canonical metadata passed a zero-error static audit.
- Result/download controls have extra spacing from future ad zones.
- Files remain browser-side in this build; some libraries are downloaded from pinned CDN URLs only when a tool needs them.

Before AdSense:
1. Deploy v6.1 over the existing v6 Vercel project.
2. Run a final live smoke test on the public URL, especially HEIC and PDF tools.
3. Only after that, connect AdSense and keep ads-config.js disabled until real publisher/slot IDs are available.
4. Configure consent/CMP requirements for applicable regions when ads are enabled.
5. If you later use a custom domain, rebuild all canonical/sitemap/robots/structured-data URLs first.
